package com.example.thinder;

import android.Manifest;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.SystemClock;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;
import androidx.core.content.ContextCompat;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.lang.reflect.Method;
import java.util.UUID;

public class MainActivity extends AppCompatActivity {

    private TextView status;
    private Button hubungkan;
    private Button cari;
    private Button matikan;
    private BluetoothAdapter adapter;
    private ArrayAdapter<String> arrayadapter;

    private final String TAG = MainActivity.class.getSimpleName();
    private Handler thandler;
    private ConnectedThread koneksi;
    private BluetoothSocket tsocket = null;
    public final static String mac = "98:DA:C0:00:0D:F7";
    private static final UUID uuid = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");

    private final static int REQUEST_ENABLE_BT = 1;
    private final static int MESSAGE_READ = 2;
    private final static int CONNECTING_STATUS = 3;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        status = (TextView)findViewById(R.id.ts);
        hubungkan = (Button)findViewById(R.id.bh);
        cari = (Button)findViewById(R.id.bc);
        matikan = (Button)findViewById(R.id.bm);

        arrayadapter = new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1);
        adapter = BluetoothAdapter.getDefaultAdapter();

        if(ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED)
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_COARSE_LOCATION}, 1);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O){
            NotificationChannel channel = new NotificationChannel("notif","My Notification",NotificationManager.IMPORTANCE_DEFAULT);
            NotificationManager manager = getSystemService(NotificationManager.class);
            manager.createNotificationChannel(channel);
        }

        thandler = new Handler(){
            public void handleMessage(android.os.Message msg){
                if(msg.what == MESSAGE_READ){
                    String readMessage = null;
                    try {
                        readMessage = new String((byte[]) msg.obj, "UTF-8");
                    } catch (UnsupportedEncodingException e) {
                        e.printStackTrace();
                    }
                }

                if(msg.what == CONNECTING_STATUS){
                    if(msg.arg1 == 1)
                        status.setText("Connected: " + (String)(msg.obj));
                    else
                        status.setText("Connection Failed");
                }
            }
        };

        if (!adapter.isEnabled()) {
            Intent enableBtIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
            startActivityForResult(enableBtIntent, REQUEST_ENABLE_BT);
            status.setText("Bluetooth Available");
            Toast.makeText(getApplicationContext(),"Bluetooth Available",Toast.LENGTH_SHORT).show();
        }
        else{
            initiateBluetoothProcess();
            Toast.makeText(getApplicationContext(),"Bluetooth Already On", Toast.LENGTH_SHORT).show();
        }

        if (arrayadapter == null) {
            status.setText("Bluetooth Not Found");
            Toast.makeText(getApplicationContext(),"Bluetooth Not Found!",Toast.LENGTH_SHORT).show();
        }
        else {
            cari.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    mencari(v);
                }
            });

            matikan.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    mematikan(v);
                }
            });

            hubungkan.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    menghubungkan(v);
                }
            });
        }
        IntentFilter filter3 = new IntentFilter(BluetoothDevice.ACTION_ACL_DISCONNECTED);
        this.registerReceiver(blReceiver,filter3);
    }

    private void menghubungkan(View view){
        initiateBluetoothProcess();
    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent Data) {
        super.onActivityResult(requestCode, resultCode, Data);
        if (requestCode == REQUEST_ENABLE_BT) {
            if (resultCode == RESULT_OK) {
                status.setText("Active");
            } else
                status.setText("Not Active");
        }
    }

    private void mencari(View view) {
        if (tsocket != null) {
            try {
                tsocket.getOutputStream().write("1".toString().getBytes());
            } catch (IOException e) {
                Toast.makeText(getApplicationContext(),"error",Toast.LENGTH_LONG).show();
            }
        }
    }

    private void mematikan(View view) {
        if (tsocket != null) {
            try {
                tsocket.getOutputStream().write("0".toString().getBytes());
            } catch (IOException e) {
                Toast.makeText(getApplicationContext(),"error",Toast.LENGTH_LONG).show();
            }
        }
    }

    final BroadcastReceiver blReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();
            BluetoothDevice device = intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE);
            if(BluetoothDevice.ACTION_FOUND.equals(action)){
                arrayadapter.add(device.getName() + "\n" + device.getAddress());
                arrayadapter.notifyDataSetChanged();
            }else if(BluetoothDevice.ACTION_ACL_DISCONNECTED.equals(action)){
                sendNotification(context);
            }
        }

        private void sendNotification(Context context) {
            NotificationCompat.Builder builder = new NotificationCompat.Builder(MainActivity.this,"notif");
            builder.setContentTitle("THINDER IS OUT OF RANGE!");
            builder.setContentText("WATCH OUT FOR GETTING LOST!!!");
            builder.setSmallIcon(R.drawable.ic_launcher_foreground);
            builder.setAutoCancel(true);
            NotificationManagerCompat managerCompat = NotificationManagerCompat.from(MainActivity.this);
            managerCompat.notify(1,builder.build());

        }
    };



    public void initiateBluetoothProcess() {

        if(!adapter.isEnabled()) {
            Toast.makeText(getBaseContext(), "Bluetooth Not Active", Toast.LENGTH_SHORT).show();
            return;
        }
        status.setText("Connecting...");

        new Thread()
        {
            public void run() {
                boolean fail = false;
                BluetoothDevice device = adapter.getRemoteDevice(mac);
                try {
                    tsocket = createBluetoothSocket(device);
                } catch (IOException e) {
                    fail = true;
                    Toast.makeText(getBaseContext(), "Connection Failed", Toast.LENGTH_SHORT).show();
                }
                try {
                    tsocket.connect();
                } catch (IOException e) {
                    try {
                        fail = true;
                        tsocket.close();
                        thandler.obtainMessage(CONNECTING_STATUS, -1, -1)
                                .sendToTarget();
                    } catch (IOException e2) {
                        Toast.makeText(getBaseContext(), "Connection Failed", Toast.LENGTH_SHORT).show();
                    }
                }

                if(fail == false) {
                    koneksi = new ConnectedThread(tsocket);
                    koneksi.start();

                    thandler.obtainMessage(CONNECTING_STATUS, 1, -1, "THINDER")
                            .sendToTarget();
                }
            }
        }.start();
    };

    private BluetoothSocket createBluetoothSocket(BluetoothDevice device) throws IOException {
        try {
            final Method m = device.getClass().getMethod("Create RFCOMM Socket to Service Record", UUID.class);
            return (BluetoothSocket) m.invoke(device, uuid);
        } catch (Exception e) {
            Log.e(TAG, "Can't Create RFCOMM Socket to Service Record",e);
        }
        return  device.createRfcommSocketToServiceRecord(uuid);
    }

    private class ConnectedThread extends Thread {
        private final BluetoothSocket fSocket;
        private final InputStream istream;
        private final OutputStream ostream;

        public ConnectedThread(BluetoothSocket socket) {
            fSocket = socket;
            InputStream tmpIn = null;
            OutputStream tmpOut = null;

            try {
                tmpIn = socket.getInputStream();
                tmpOut = socket.getOutputStream();
            } catch (IOException e) { }

            istream = tmpIn;
            ostream = tmpOut;
        }

        public void run() {
            byte[] buffer = new byte[1024];
            int bytes;
            while (true) {
                try {
                    bytes = istream.available();
                    if(bytes != 0) {
                        buffer = new byte[1024];
                        SystemClock.sleep(100);
                        bytes = istream.available();
                        bytes = istream.read(buffer, 0, bytes);
                        thandler.obtainMessage(MESSAGE_READ, bytes, -1, buffer)
                                .sendToTarget();
                    }
                } catch (IOException e) {
                    e.printStackTrace();

                    break;
                }
            }
        }

        public void write(String input) {
            byte[] bytes = input.getBytes();
            try {
                ostream.write(bytes);
            } catch (IOException e) { }
        }

        public void cancel() {
            try {
                fSocket.close();
            } catch (IOException e) { }
        }
    }
}
